//
//  ChildData+CoreDataProperties.swift
//  Core Data Basic Save Fetch
//
//  Created by Abdur Razzak on 19/8/23.
//
//

import Foundation
import CoreData


extension ChildData {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ChildData> {
        return NSFetchRequest<ChildData>(entityName: "ChildData")
    }

    @NSManaged public var childname: String?

}

extension ChildData : Identifiable {

}
