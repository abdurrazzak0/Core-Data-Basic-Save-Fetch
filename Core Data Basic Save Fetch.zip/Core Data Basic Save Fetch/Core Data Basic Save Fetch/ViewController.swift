//
//  ViewController.swift
//  Core Data Basic Save Fetch
//
//  Created by Abdur Razzak on 19/8/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet var myText: UITextField!
    
   // var cData = [ChildData]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func addNewChildren(_ sender: Any) {
        let appDe = (UIApplication.shared.delegate) as? AppDelegate
        let context = appDe?.persistentContainer.viewContext
        let childData = NSEntityDescription.insertNewObject(forEntityName: "ChildData", into: context) as! ChildData
        childData.childname = myText.text
        do
        {
            try context?.save()
            print ("Data has Been Saved Successfully")
            myText.text = ""
            
            catch {
                print("Eroor Occured While Saving Data")
            }
        }
    
            
            
    @IBAction func fetchAllChildrens(_ sender: Any) {
        let appDe = (UIApplication.shared.delegate) as! AppDelegate
        let context = appDe.persistentContainer.viewContext
        do{
            let cdata = try context.fetch(ChildData.fetchRequest() as! [ChildData]
        }
        catch
    }
    print ("Error Occured While Fetching Data")
}

