//
//  ChildData+CoreDataClass.swift
//  Core Data Basic Save Fetch
//
//  Created by Abdur Razzak on 19/8/23.
//
//

import Foundation
import CoreData


public class ChildData: NSManagedObject {

}
